import React from 'react';

function Books(props) {
    return (
        <div>
            书籍
        </div>
    );
}

export default Books;