import React from 'react';

function Interviews(props) {
    return (
        <div>
            面试题
        </div>
    );
}

export default Interviews;