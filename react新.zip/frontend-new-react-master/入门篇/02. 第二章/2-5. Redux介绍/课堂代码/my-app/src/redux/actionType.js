// 描述了 action 对象的类型

export const ADD = "ADD"; // 新增
export const DEL = "DEL"; // 删除
export const CHANGE = "CHANGE"; // 修改状态