import React from 'react';

function Email(props) {
    return (
        <div>
            邮箱地址：xxx@.com
        </div>
    );
}

export default Email;