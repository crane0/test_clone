import React from 'react';

function Tel(props) {
    return (
        <div>
            电话号码：131-xxxx-xxxx
        </div>
    );
}

export default Tel;