import React from 'react';

function Add(props) {
    return (
        <div>
            Add
        </div>
    );
}

export default Add;