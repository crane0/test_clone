function App() {
  return (
    <div>Hello React~</div>
  );
}

export default App;
