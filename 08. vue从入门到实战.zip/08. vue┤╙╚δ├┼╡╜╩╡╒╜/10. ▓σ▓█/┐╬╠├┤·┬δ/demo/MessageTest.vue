<template>
  <Message>
    <div>
      <a href="">asdfasfd</a>
      <p>asdfasdfa</p>
    </div>
  </Message>
</template>

<script>
import Message from "./Message";
export default {
  components: {
    Message,
  },
};
</script>

<style></style>
