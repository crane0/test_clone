import "./banner";
import "./blog";
import Mock from "mockjs";
Mock.setup({
  timeout: "1000-2000",
});
