<template>
  <h1>文章</h1>
</template>

<script>
export default {};
</script>

<style></style>
