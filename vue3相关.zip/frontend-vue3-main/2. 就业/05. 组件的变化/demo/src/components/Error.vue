<template>
  <h3><slot></slot></h3>
</template>

<style scoped>
h3 {
  color: #f40;
}
</style>
