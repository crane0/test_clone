<template>
  <h2>异步区域5</h2>
</template>
