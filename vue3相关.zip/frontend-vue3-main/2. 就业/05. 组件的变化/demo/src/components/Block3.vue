<template>
  <h2>异步区域3</h2>
</template>
