module.exports = {
  extends: 'airbnb',
};
