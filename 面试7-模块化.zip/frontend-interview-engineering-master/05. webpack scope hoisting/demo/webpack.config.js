module.exports = {
  devtool: 'none',
};
