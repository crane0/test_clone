import bigPic from './assets/big-pic.png'; // 期望得到路径
import smallPic from './assets/small-pic.jpg'; // 期望得到base64
import yueyunpeng from './assets/yueyunpeng.gif'; // 期望根据文件大小决定是路径还是base64
import raw from './assets/raw.txt'; // 期望得到原始文件内容

console.log('big-pic.png', bigPic);
console.log('small-pic.jpg', smallPic);
console.log('yueyunpeng.gif', yueyunpeng);
console.log('raw.txt', raw);
