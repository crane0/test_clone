import React from 'react';
import ReactDOM from 'react-dom';
import BallList from "./components/BallList"

ReactDOM.render(<BallList/>, document.getElementById('root'));
