import React from 'react';
import ReactDOM from 'react-dom';
import PagerTest from "./components/PagerTest"

ReactDOM.render(<PagerTest/>, document.getElementById('root'));
