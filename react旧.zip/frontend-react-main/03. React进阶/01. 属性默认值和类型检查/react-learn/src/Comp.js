import React from 'react'

export default function Comp() {
    return (
        <div>
            <h1>Comp</h1>
        </div>
    )
}
