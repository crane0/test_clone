import React from 'react'
import Test from "./components/Test"

export default function App() {
    return (
        <Test />
    )
}
