import React from "react"

const ctx = React.createContext();

export const { Provider, Consumer } = ctx

export default ctx