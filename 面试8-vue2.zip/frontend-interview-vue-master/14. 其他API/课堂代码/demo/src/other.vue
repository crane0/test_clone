<template>
  <h1>Hello World</h1>
</template>

<script>
export default {
  created() {
    console.log('other');
  },
};
</script>

<style></style>
