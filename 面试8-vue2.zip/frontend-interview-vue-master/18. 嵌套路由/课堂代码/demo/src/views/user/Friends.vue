<template>
  <h1 class="text-2xl text-center font-bold">User Friends</h1>
</template>
