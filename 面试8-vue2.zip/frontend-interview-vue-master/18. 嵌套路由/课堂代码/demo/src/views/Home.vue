<template>
  <h1 class="text-2xl text-center font-bold">Home Page</h1>
</template>
