export default {
  routerSwitch: {
    fromIndex: 0,
    toIndex: 0,
    direction: 'right',
  },
};
